all code in index.html page
used bootstrap and native css
